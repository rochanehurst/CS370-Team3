/********************************************************************************
** Form generated from reading UI file 'createclass.ui'
**
** Created by: Qt User Interface Compiler version 6.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATECLASS_H
#define UI_CREATECLASS_H

#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTimeEdit>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QFormLayout *formLayout;
    QLabel *building_name_label;
    QComboBox *building_name;
    QLabel *name_label;
    QLineEdit *class_name;
    QLabel *start_time_label;
    QHBoxLayout *class_time_layout;
    QTimeEdit *time_start;
    QLabel *end_time_label;
    QTimeEdit *time_stop;
    QSpacerItem *horizontal_spacer;
    QLabel *days_label;
    QFrame *days;
    QVBoxLayout *verticalLayout;
    QCheckBox *monday;
    QCheckBox *tuesday;
    QCheckBox *wednesday;
    QCheckBox *thursday;
    QCheckBox *friday;
    QCheckBox *saturday;
    QDialogButtonBox *confirm_button_box;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName("Dialog");
        Dialog->setEnabled(true);
        Dialog->resize(350, 290);
        QSizePolicy sizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Dialog->sizePolicy().hasHeightForWidth());
        Dialog->setSizePolicy(sizePolicy);
        Dialog->setMinimumSize(QSize(350, 250));
        Dialog->setMaximumSize(QSize(350, 290));
        QPalette palette;
        QBrush brush(QColor(11, 40, 85, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Button, brush);
        QBrush brush1(QColor(215, 231, 255, 255));
        brush1.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Light, brush1);
        QBrush brush2(QColor(111, 111, 111, 255));
        brush2.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Dark, brush2);
        QBrush brush3(QColor(3, 10, 21, 255));
        brush3.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Mid, brush3);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Text, brush3);
        QBrush brush4(QColor(255, 0, 0, 255));
        brush4.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::BrightText, brush4);
        QBrush brush5(QColor(255, 255, 255, 255));
        brush5.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ButtonText, brush5);
        QBrush brush6(QColor(153, 155, 159, 255));
        brush6.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Base, brush6);
        QBrush brush7(QColor(172, 172, 172, 255));
        brush7.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush7);
        QBrush brush8(QColor(6, 21, 43, 255));
        brush8.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Shadow, brush8);
        QBrush brush9(QColor(16, 61, 127, 255));
        brush9.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Highlight, brush9);
        QBrush brush10(QColor(0, 0, 255, 255));
        brush10.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Link, brush10);
        QBrush brush11(QColor(255, 85, 0, 255));
        brush11.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::LinkVisited, brush11);
        QBrush brush12(QColor(85, 119, 165, 255));
        brush12.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::AlternateBase, brush12);
        QBrush brush13(QColor(170, 255, 0, 255));
        brush13.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ToolTipBase, brush13);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ToolTipText, brush13);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Accent, brush);
#endif
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Button, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Light, brush1);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Dark, brush2);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Mid, brush3);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Text, brush3);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::BrightText, brush4);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ButtonText, brush5);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Base, brush6);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush7);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Shadow, brush8);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Highlight, brush9);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Link, brush10);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::LinkVisited, brush11);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::AlternateBase, brush12);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ToolTipBase, brush13);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ToolTipText, brush13);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Accent, brush);
#endif
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::WindowText, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Button, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Light, brush1);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Dark, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Mid, brush3);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Text, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::BrightText, brush4);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ButtonText, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush7);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush7);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Shadow, brush8);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Link, brush10);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::LinkVisited, brush11);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::AlternateBase, brush12);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ToolTipBase, brush13);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ToolTipText, brush13);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Accent, brush);
#endif
        Dialog->setPalette(palette);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/icons/Create Class Icon Placeholder.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        Dialog->setWindowIcon(icon);
        Dialog->setSizeGripEnabled(true);
        formLayout = new QFormLayout(Dialog);
        formLayout->setObjectName("formLayout");
        building_name_label = new QLabel(Dialog);
        building_name_label->setObjectName("building_name_label");
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(building_name_label->sizePolicy().hasHeightForWidth());
        building_name_label->setSizePolicy(sizePolicy1);
        building_name_label->setMinimumSize(QSize(0, 24));
        building_name_label->setAlignment(Qt::AlignmentFlag::AlignLeading|Qt::AlignmentFlag::AlignLeft|Qt::AlignmentFlag::AlignVCenter);

        formLayout->setWidget(0, QFormLayout::ItemRole::LabelRole, building_name_label);

        building_name = new QComboBox(Dialog);
        building_name->addItem(QString());
        building_name->addItem(QString());
        building_name->addItem(QString());
        building_name->addItem(QString());
        building_name->addItem(QString());
        building_name->addItem(QString());
        building_name->addItem(QString());
        building_name->addItem(QString());
        building_name->addItem(QString());
        building_name->addItem(QString());
        building_name->addItem(QString());
        building_name->addItem(QString());
        building_name->setObjectName("building_name");
        building_name->setMaxVisibleItems(15);

        formLayout->setWidget(0, QFormLayout::ItemRole::FieldRole, building_name);

        name_label = new QLabel(Dialog);
        name_label->setObjectName("name_label");
        QSizePolicy sizePolicy2(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(name_label->sizePolicy().hasHeightForWidth());
        name_label->setSizePolicy(sizePolicy2);
        name_label->setMinimumSize(QSize(0, 24));
        name_label->setAlignment(Qt::AlignmentFlag::AlignLeading|Qt::AlignmentFlag::AlignLeft|Qt::AlignmentFlag::AlignVCenter);

        formLayout->setWidget(1, QFormLayout::ItemRole::LabelRole, name_label);

        class_name = new QLineEdit(Dialog);
        class_name->setObjectName("class_name");
        QSizePolicy sizePolicy3(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(class_name->sizePolicy().hasHeightForWidth());
        class_name->setSizePolicy(sizePolicy3);

        formLayout->setWidget(1, QFormLayout::ItemRole::FieldRole, class_name);

        start_time_label = new QLabel(Dialog);
        start_time_label->setObjectName("start_time_label");
        sizePolicy1.setHeightForWidth(start_time_label->sizePolicy().hasHeightForWidth());
        start_time_label->setSizePolicy(sizePolicy1);
        start_time_label->setMinimumSize(QSize(0, 24));
        start_time_label->setAlignment(Qt::AlignmentFlag::AlignLeading|Qt::AlignmentFlag::AlignLeft|Qt::AlignmentFlag::AlignVCenter);

        formLayout->setWidget(2, QFormLayout::ItemRole::LabelRole, start_time_label);

        class_time_layout = new QHBoxLayout();
        class_time_layout->setSpacing(0);
        class_time_layout->setObjectName("class_time_layout");
        class_time_layout->setContentsMargins(0, -1, 0, -1);
        time_start = new QTimeEdit(Dialog);
        time_start->setObjectName("time_start");
        sizePolicy1.setHeightForWidth(time_start->sizePolicy().hasHeightForWidth());
        time_start->setSizePolicy(sizePolicy1);
        time_start->setMaximumSize(QSize(16777215, 24));
        time_start->setAccelerated(false);
        time_start->setDateTime(QDateTime(QDate(2000, 1, 1), QTime(0, 0, 0)));
        time_start->setMaximumDateTime(QDateTime(QDate(2000, 1, 1), QTime(23, 59, 59)));
        time_start->setMinimumDateTime(QDateTime(QDate(2000, 1, 1), QTime(0, 0, 0)));
        time_start->setMaximumDate(QDate(2000, 1, 1));
        time_start->setMinimumDate(QDate(2000, 1, 1));
        time_start->setMaximumTime(QTime(23, 59, 59));
        time_start->setMinimumTime(QTime(0, 0, 0));
        time_start->setTime(QTime(0, 0, 0));

        class_time_layout->addWidget(time_start);

        end_time_label = new QLabel(Dialog);
        end_time_label->setObjectName("end_time_label");
        QSizePolicy sizePolicy4(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(end_time_label->sizePolicy().hasHeightForWidth());
        end_time_label->setSizePolicy(sizePolicy4);
        end_time_label->setMinimumSize(QSize(20, 0));
        end_time_label->setMaximumSize(QSize(16777215, 16777215));
        end_time_label->setAlignment(Qt::AlignmentFlag::AlignCenter);

        class_time_layout->addWidget(end_time_label);

        time_stop = new QTimeEdit(Dialog);
        time_stop->setObjectName("time_stop");
        sizePolicy1.setHeightForWidth(time_stop->sizePolicy().hasHeightForWidth());
        time_stop->setSizePolicy(sizePolicy1);
        time_stop->setMinimumSize(QSize(0, 0));
        time_stop->setMaximumSize(QSize(16777215, 24));
        time_stop->setAccelerated(false);
        time_stop->setMaximumDateTime(QDateTime(QDate(2000, 1, 1), QTime(0, 0, 0)));
        time_stop->setMinimumDateTime(QDateTime(QDate(2000, 1, 1), QTime(0, 0, 0)));
        time_stop->setMaximumDate(QDate(2000, 1, 1));
        time_stop->setMinimumDate(QDate(2000, 1, 1));
        time_stop->setMaximumTime(QTime(0, 0, 0));
        time_stop->setMinimumTime(QTime(0, 0, 0));
        time_stop->setTime(QTime(0, 0, 0));

        class_time_layout->addWidget(time_stop);

        horizontal_spacer = new QSpacerItem(20, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        class_time_layout->addItem(horizontal_spacer);


        formLayout->setLayout(2, QFormLayout::ItemRole::FieldRole, class_time_layout);

        days_label = new QLabel(Dialog);
        days_label->setObjectName("days_label");
        sizePolicy1.setHeightForWidth(days_label->sizePolicy().hasHeightForWidth());
        days_label->setSizePolicy(sizePolicy1);
        days_label->setMinimumSize(QSize(0, 150));
        days_label->setAlignment(Qt::AlignmentFlag::AlignLeading|Qt::AlignmentFlag::AlignLeft|Qt::AlignmentFlag::AlignVCenter);

        formLayout->setWidget(3, QFormLayout::ItemRole::LabelRole, days_label);

        days = new QFrame(Dialog);
        days->setObjectName("days");
        days->setEnabled(true);
        sizePolicy1.setHeightForWidth(days->sizePolicy().hasHeightForWidth());
        days->setSizePolicy(sizePolicy1);
        days->setMinimumSize(QSize(0, 0));
        days->setMaximumSize(QSize(16777215, 150));
        days->setFrameShape(QFrame::Shape::StyledPanel);
        days->setFrameShadow(QFrame::Shadow::Raised);
        verticalLayout = new QVBoxLayout(days);
        verticalLayout->setObjectName("verticalLayout");
        monday = new QCheckBox(days);
        monday->setObjectName("monday");

        verticalLayout->addWidget(monday);

        tuesday = new QCheckBox(days);
        tuesday->setObjectName("tuesday");

        verticalLayout->addWidget(tuesday);

        wednesday = new QCheckBox(days);
        wednesday->setObjectName("wednesday");

        verticalLayout->addWidget(wednesday);

        thursday = new QCheckBox(days);
        thursday->setObjectName("thursday");

        verticalLayout->addWidget(thursday);

        friday = new QCheckBox(days);
        friday->setObjectName("friday");

        verticalLayout->addWidget(friday, 0, Qt::AlignmentFlag::AlignLeft);

        saturday = new QCheckBox(days);
        saturday->setObjectName("saturday");

        verticalLayout->addWidget(saturday, 0, Qt::AlignmentFlag::AlignLeft);


        formLayout->setWidget(3, QFormLayout::ItemRole::FieldRole, days);

        confirm_button_box = new QDialogButtonBox(Dialog);
        confirm_button_box->setObjectName("confirm_button_box");
        sizePolicy4.setHeightForWidth(confirm_button_box->sizePolicy().hasHeightForWidth());
        confirm_button_box->setSizePolicy(sizePolicy4);
        confirm_button_box->setOrientation(Qt::Orientation::Horizontal);
        confirm_button_box->setStandardButtons(QDialogButtonBox::StandardButton::Cancel|QDialogButtonBox::StandardButton::Ok);

        formLayout->setWidget(4, QFormLayout::ItemRole::FieldRole, confirm_button_box);

        QWidget::setTabOrder(friday, tuesday);
        QWidget::setTabOrder(tuesday, wednesday);
        QWidget::setTabOrder(wednesday, thursday);

        retranslateUi(Dialog);
        QObject::connect(confirm_button_box, &QDialogButtonBox::rejected, Dialog, qOverload<>(&QDialog::reject));
        QObject::connect(confirm_button_box, &QDialogButtonBox::accepted, Dialog, qOverload<>(&QDialog::accept));

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QCoreApplication::translate("Dialog", "Creat Class", nullptr));
#if QT_CONFIG(tooltip)
        Dialog->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        building_name_label->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        building_name_label->setText(QCoreApplication::translate("Dialog", "Building", nullptr));
        building_name->setItemText(0, QCoreApplication::translate("Dialog", "--SELECT BUILDING--", nullptr));
        building_name->setItemText(1, QCoreApplication::translate("Dialog", "Academic Hall", nullptr));
        building_name->setItemText(2, QCoreApplication::translate("Dialog", "Arts Building", nullptr));
        building_name->setItemText(3, QCoreApplication::translate("Dialog", "Extended Learning Building", nullptr));
        building_name->setItemText(4, QCoreApplication::translate("Dialog", "Kellogg Library", nullptr));
        building_name->setItemText(5, QCoreApplication::translate("Dialog", "Markstein Hall", nullptr));
        building_name->setItemText(6, QCoreApplication::translate("Dialog", "Science Hall I", nullptr));
        building_name->setItemText(7, QCoreApplication::translate("Dialog", "Science Hall II", nullptr));
        building_name->setItemText(8, QCoreApplication::translate("Dialog", "Social and Behavioral Sciences Building", nullptr));
        building_name->setItemText(9, QCoreApplication::translate("Dialog", "University Hall", nullptr));
        building_name->setItemText(10, QCoreApplication::translate("Dialog", "Viasat Engineering Pavilion", nullptr));
        building_name->setItemText(11, QCoreApplication::translate("Dialog", "ONLINE CLASS", nullptr));

        building_name->setCurrentText(QCoreApplication::translate("Dialog", "--SELECT BUILDING--", nullptr));
#if QT_CONFIG(tooltip)
        name_label->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        name_label->setText(QCoreApplication::translate("Dialog", "Name", nullptr));
#if QT_CONFIG(tooltip)
        class_name->setToolTip(QCoreApplication::translate("Dialog", "<html><head/><body><p>Enter class name</p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        start_time_label->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        start_time_label->setText(QCoreApplication::translate("Dialog", "Duration", nullptr));
#if QT_CONFIG(tooltip)
        time_start->setToolTip(QCoreApplication::translate("Dialog", "<html><head/><body><p>Set class start time</p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        time_start->setDisplayFormat(QCoreApplication::translate("Dialog", "h:mmA", nullptr));
#if QT_CONFIG(tooltip)
        end_time_label->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        end_time_label->setText(QCoreApplication::translate("Dialog", "to", nullptr));
#if QT_CONFIG(tooltip)
        time_stop->setToolTip(QCoreApplication::translate("Dialog", "<html><head/><body><p>Set class end time</p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        time_stop->setDisplayFormat(QCoreApplication::translate("Dialog", "h:mmA", nullptr));
#if QT_CONFIG(tooltip)
        days_label->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        days_label->setText(QCoreApplication::translate("Dialog", "Days", nullptr));
#if QT_CONFIG(tooltip)
        days->setToolTip(QCoreApplication::translate("Dialog", "<html><head/><body><p>Select days in which class occurs</p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        monday->setText(QCoreApplication::translate("Dialog", "Monday", nullptr));
        tuesday->setText(QCoreApplication::translate("Dialog", "Tuesday", nullptr));
        wednesday->setText(QCoreApplication::translate("Dialog", "Wednesday", nullptr));
        thursday->setText(QCoreApplication::translate("Dialog", "Thursday", nullptr));
        friday->setText(QCoreApplication::translate("Dialog", "Friday", nullptr));
        saturday->setText(QCoreApplication::translate("Dialog", "Saturday", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATECLASS_H
