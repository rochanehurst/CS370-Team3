/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_main_window
{
public:
    QAction *actionPopulate_Schedule;
    QAction *actionAdd_Random_Class;
    QAction *actionError;
    QAction *actionWarning;
    QAction *actionNotice;
    QWidget *main_window_grid;
    QGridLayout *gridLayout;
    QSplitter *splitter;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *schedule_layout;
    QHBoxLayout *schedule_title;
    QPushButton *update_class_list;
    QSpacerItem *horizontalSpacer_2;
    QLabel *class_label;
    QSpacerItem *horizontalSpacer;
    QPushButton *class_creator_button;
    QPushButton *clear_schedule_button;
    QScrollArea *class_container;
    QWidget *class_scroll_area;
    QVBoxLayout *verticalLayout;
    QVBoxLayout *class_list;
    QWidget *verticalLayoutWidget_3;
    QVBoxLayout *map_layout;
    QLabel *CSUSM_label;
    QGraphicsView *map_placeholder;
    QMenuBar *menuBar;
    QMenu *menuDebug;

    void setupUi(QMainWindow *main_window)
    {
        if (main_window->objectName().isEmpty())
            main_window->setObjectName("main_window");
        main_window->resize(1050, 600);
        QSizePolicy sizePolicy(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(main_window->sizePolicy().hasHeightForWidth());
        main_window->setSizePolicy(sizePolicy);
        main_window->setMinimumSize(QSize(1050, 600));
        QPalette palette;
        QBrush brush(QColor(11, 40, 85, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Button, brush);
        QBrush brush1(QColor(215, 231, 255, 255));
        brush1.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Light, brush1);
        QBrush brush2(QColor(111, 111, 111, 255));
        brush2.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Dark, brush2);
        QBrush brush3(QColor(3, 10, 21, 255));
        brush3.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Mid, brush3);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Text, brush3);
        QBrush brush4(QColor(255, 0, 0, 255));
        brush4.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::BrightText, brush4);
        QBrush brush5(QColor(255, 255, 255, 255));
        brush5.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ButtonText, brush5);
        QBrush brush6(QColor(153, 155, 159, 255));
        brush6.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Base, brush6);
        QBrush brush7(QColor(172, 172, 172, 255));
        brush7.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush7);
        QBrush brush8(QColor(6, 21, 43, 255));
        brush8.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Shadow, brush8);
        QBrush brush9(QColor(16, 61, 127, 255));
        brush9.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Highlight, brush9);
        QBrush brush10(QColor(0, 0, 255, 255));
        brush10.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Link, brush10);
        QBrush brush11(QColor(255, 85, 0, 255));
        brush11.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::LinkVisited, brush11);
        QBrush brush12(QColor(85, 119, 165, 255));
        brush12.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::AlternateBase, brush12);
        QBrush brush13(QColor(170, 255, 0, 255));
        brush13.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ToolTipBase, brush13);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ToolTipText, brush13);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Accent, brush);
#endif
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Button, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Light, brush1);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Dark, brush2);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Mid, brush3);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Text, brush3);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::BrightText, brush4);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ButtonText, brush5);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Base, brush6);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush7);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Shadow, brush8);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Highlight, brush9);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Link, brush10);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::LinkVisited, brush11);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::AlternateBase, brush12);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ToolTipBase, brush13);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ToolTipText, brush13);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Accent, brush);
#endif
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::WindowText, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Button, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Light, brush1);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Dark, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Mid, brush3);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Text, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::BrightText, brush4);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ButtonText, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush7);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush7);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Shadow, brush8);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Link, brush10);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::LinkVisited, brush11);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::AlternateBase, brush12);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ToolTipBase, brush13);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ToolTipText, brush13);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Accent, brush);
#endif
        main_window->setPalette(palette);
        QFont font;
        font.setFamilies({QString::fromUtf8("Lucida Console")});
        main_window->setFont(font);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/icons/Cluster Window Icon Placeholder.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        main_window->setWindowIcon(icon);
        main_window->setToolButtonStyle(Qt::ToolButtonStyle::ToolButtonTextOnly);
        actionPopulate_Schedule = new QAction(main_window);
        actionPopulate_Schedule->setObjectName("actionPopulate_Schedule");
        actionAdd_Random_Class = new QAction(main_window);
        actionAdd_Random_Class->setObjectName("actionAdd_Random_Class");
        actionError = new QAction(main_window);
        actionError->setObjectName("actionError");
        actionWarning = new QAction(main_window);
        actionWarning->setObjectName("actionWarning");
        actionNotice = new QAction(main_window);
        actionNotice->setObjectName("actionNotice");
        main_window_grid = new QWidget(main_window);
        main_window_grid->setObjectName("main_window_grid");
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(main_window_grid->sizePolicy().hasHeightForWidth());
        main_window_grid->setSizePolicy(sizePolicy1);
        QPalette palette1;
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Button, brush);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Light, brush1);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Dark, brush13);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Mid, brush3);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Text, brush3);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::BrightText, brush4);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ButtonText, brush5);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Base, brush6);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush7);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Shadow, brush8);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Highlight, brush9);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Link, brush10);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::LinkVisited, brush11);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::AlternateBase, brush12);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ToolTipBase, brush13);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ToolTipText, brush13);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Accent, brush);
#endif
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Button, brush);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Light, brush1);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Dark, brush13);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Mid, brush3);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Text, brush3);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::BrightText, brush4);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ButtonText, brush5);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Base, brush6);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush7);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Shadow, brush8);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Highlight, brush9);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Link, brush10);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::LinkVisited, brush11);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::AlternateBase, brush12);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ToolTipBase, brush13);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ToolTipText, brush13);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Accent, brush);
#endif
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::WindowText, brush13);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Button, brush);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Light, brush1);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Dark, brush13);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Mid, brush3);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Text, brush13);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::BrightText, brush4);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ButtonText, brush13);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush7);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush7);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Shadow, brush8);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Link, brush10);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::LinkVisited, brush11);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::AlternateBase, brush12);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ToolTipBase, brush13);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ToolTipText, brush13);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Accent, brush);
#endif
        main_window_grid->setPalette(palette1);
        gridLayout = new QGridLayout(main_window_grid);
        gridLayout->setSpacing(6);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(6, 6, 6, 6);
        splitter = new QSplitter(main_window_grid);
        splitter->setObjectName("splitter");
        sizePolicy.setHeightForWidth(splitter->sizePolicy().hasHeightForWidth());
        splitter->setSizePolicy(sizePolicy);
        splitter->setFrameShape(QFrame::Shape::NoFrame);
        splitter->setLineWidth(0);
        splitter->setMidLineWidth(2);
        splitter->setOrientation(Qt::Orientation::Horizontal);
        splitter->setHandleWidth(3);
        splitter->setChildrenCollapsible(false);
        verticalLayoutWidget_2 = new QWidget(splitter);
        verticalLayoutWidget_2->setObjectName("verticalLayoutWidget_2");
        schedule_layout = new QVBoxLayout(verticalLayoutWidget_2);
        schedule_layout->setSpacing(5);
        schedule_layout->setObjectName("schedule_layout");
        schedule_layout->setSizeConstraint(QLayout::SizeConstraint::SetDefaultConstraint);
        schedule_layout->setContentsMargins(4, 4, 4, 5);
        schedule_title = new QHBoxLayout();
        schedule_title->setSpacing(6);
        schedule_title->setObjectName("schedule_title");
        update_class_list = new QPushButton(verticalLayoutWidget_2);
        update_class_list->setObjectName("update_class_list");
        QSizePolicy sizePolicy2(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(update_class_list->sizePolicy().hasHeightForWidth());
        update_class_list->setSizePolicy(sizePolicy2);
        update_class_list->setMinimumSize(QSize(0, 40));
        update_class_list->setMaximumSize(QSize(200, 16777215));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Courier New")});
        font1.setPointSize(12);
        font1.setBold(true);
        update_class_list->setFont(font1);
        update_class_list->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));

        schedule_title->addWidget(update_class_list);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        schedule_title->addItem(horizontalSpacer_2);

        class_label = new QLabel(verticalLayoutWidget_2);
        class_label->setObjectName("class_label");
        sizePolicy2.setHeightForWidth(class_label->sizePolicy().hasHeightForWidth());
        class_label->setSizePolicy(sizePolicy2);
        class_label->setMinimumSize(QSize(0, 40));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Courier New")});
        font2.setPointSize(20);
        font2.setBold(true);
        class_label->setFont(font2);
        class_label->setScaledContents(true);

        schedule_title->addWidget(class_label, 0, Qt::AlignmentFlag::AlignHCenter|Qt::AlignmentFlag::AlignTop);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        schedule_title->addItem(horizontalSpacer);

        class_creator_button = new QPushButton(verticalLayoutWidget_2);
        class_creator_button->setObjectName("class_creator_button");
        QSizePolicy sizePolicy3(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(class_creator_button->sizePolicy().hasHeightForWidth());
        class_creator_button->setSizePolicy(sizePolicy3);
        class_creator_button->setMinimumSize(QSize(40, 40));
        class_creator_button->setMaximumSize(QSize(40, 40));
        QFont font3;
        font3.setFamilies({QString::fromUtf8("Lucida Console")});
        font3.setPointSize(36);
        class_creator_button->setFont(font3);
        class_creator_button->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        class_creator_button->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	background-color: rgb(11, 40, 85);\n"
"	color: white;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgb(172, 172, 172);\n"
"	color: white;\n"
"}\n"
"QPushButton::menu-indicator { \n"
"	image: none; \n"
"	width: 0px; \n"
"}"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/icons/icons/add_button.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        class_creator_button->setIcon(icon1);
        class_creator_button->setIconSize(QSize(36, 36));

        schedule_title->addWidget(class_creator_button, 0, Qt::AlignmentFlag::AlignRight|Qt::AlignmentFlag::AlignTop);

        clear_schedule_button = new QPushButton(verticalLayoutWidget_2);
        clear_schedule_button->setObjectName("clear_schedule_button");
        sizePolicy3.setHeightForWidth(clear_schedule_button->sizePolicy().hasHeightForWidth());
        clear_schedule_button->setSizePolicy(sizePolicy3);
        clear_schedule_button->setMinimumSize(QSize(40, 40));
        clear_schedule_button->setMaximumSize(QSize(40, 40));
        clear_schedule_button->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        clear_schedule_button->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	background-color: rgb(11, 40, 85);\n"
"	color: white;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgb(172, 172, 172);\n"
"	color: white;\n"
"}"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/icons/icons/trash-can-icon.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        clear_schedule_button->setIcon(icon2);
        clear_schedule_button->setIconSize(QSize(32, 32));

        schedule_title->addWidget(clear_schedule_button, 0, Qt::AlignmentFlag::AlignRight|Qt::AlignmentFlag::AlignTop);


        schedule_layout->addLayout(schedule_title);

        class_container = new QScrollArea(verticalLayoutWidget_2);
        class_container->setObjectName("class_container");
        sizePolicy.setHeightForWidth(class_container->sizePolicy().hasHeightForWidth());
        class_container->setSizePolicy(sizePolicy);
        class_container->setMinimumSize(QSize(400, 200));
        class_container->setMaximumSize(QSize(16777215, 16777215));
        class_container->setWidgetResizable(true);
        class_container->setAlignment(Qt::AlignmentFlag::AlignCenter);
        class_scroll_area = new QWidget();
        class_scroll_area->setObjectName("class_scroll_area");
        class_scroll_area->setGeometry(QRect(0, 0, 506, 513));
        sizePolicy.setHeightForWidth(class_scroll_area->sizePolicy().hasHeightForWidth());
        class_scroll_area->setSizePolicy(sizePolicy);
        verticalLayout = new QVBoxLayout(class_scroll_area);
        verticalLayout->setObjectName("verticalLayout");
        class_list = new QVBoxLayout();
        class_list->setSpacing(20);
        class_list->setObjectName("class_list");

        verticalLayout->addLayout(class_list);

        class_container->setWidget(class_scroll_area);

        schedule_layout->addWidget(class_container);

        schedule_layout->setStretch(1, 1);
        splitter->addWidget(verticalLayoutWidget_2);
        verticalLayoutWidget_3 = new QWidget(splitter);
        verticalLayoutWidget_3->setObjectName("verticalLayoutWidget_3");
        map_layout = new QVBoxLayout(verticalLayoutWidget_3);
        map_layout->setObjectName("map_layout");
        map_layout->setContentsMargins(5, 5, 5, 5);
        CSUSM_label = new QLabel(verticalLayoutWidget_3);
        CSUSM_label->setObjectName("CSUSM_label");
        sizePolicy2.setHeightForWidth(CSUSM_label->sizePolicy().hasHeightForWidth());
        CSUSM_label->setSizePolicy(sizePolicy2);
        CSUSM_label->setMinimumSize(QSize(300, 40));
        CSUSM_label->setMaximumSize(QSize(16777215, 16777215));
        CSUSM_label->setFont(font2);
        CSUSM_label->setAlignment(Qt::AlignmentFlag::AlignCenter);

        map_layout->addWidget(CSUSM_label);

        map_placeholder = new QGraphicsView(verticalLayoutWidget_3);
        map_placeholder->setObjectName("map_placeholder");
        sizePolicy.setHeightForWidth(map_placeholder->sizePolicy().hasHeightForWidth());
        map_placeholder->setSizePolicy(sizePolicy);
        map_placeholder->setMinimumSize(QSize(400, 200));
        map_placeholder->setMaximumSize(QSize(16777215, 16777215));
        map_placeholder->viewport()->setProperty("cursor", QVariant(QCursor(Qt::CursorShape::PointingHandCursor)));
        map_placeholder->setFrameShape(QFrame::Shape::Box);
        map_placeholder->setLineWidth(0);
        map_placeholder->setMidLineWidth(1);
        QBrush brush14(QColor(0, 0, 0, 255));
        brush14.setStyle(Qt::BrushStyle::NoBrush);
        map_placeholder->setBackgroundBrush(brush14);

        map_layout->addWidget(map_placeholder);

        map_layout->setStretch(1, 1);
        splitter->addWidget(verticalLayoutWidget_3);

        gridLayout->addWidget(splitter, 0, 0, 1, 1);

        main_window->setCentralWidget(main_window_grid);
        menuBar = new QMenuBar(main_window);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 1050, 17));
        menuDebug = new QMenu(menuBar);
        menuDebug->setObjectName("menuDebug");
        main_window->setMenuBar(menuBar);

        menuBar->addAction(menuDebug->menuAction());
        menuDebug->addAction(actionPopulate_Schedule);
        menuDebug->addAction(actionAdd_Random_Class);

        retranslateUi(main_window);

        QMetaObject::connectSlotsByName(main_window);
    } // setupUi

    void retranslateUi(QMainWindow *main_window)
    {
        main_window->setWindowTitle(QCoreApplication::translate("main_window", "Cluster Scheduling App", nullptr));
        actionPopulate_Schedule->setText(QCoreApplication::translate("main_window", "Populate Schedule", nullptr));
        actionAdd_Random_Class->setText(QCoreApplication::translate("main_window", "Add Random Class", nullptr));
        actionError->setText(QCoreApplication::translate("main_window", "Error", nullptr));
        actionWarning->setText(QCoreApplication::translate("main_window", "Warning", nullptr));
        actionNotice->setText(QCoreApplication::translate("main_window", "Notice", nullptr));
#if QT_CONFIG(tooltip)
        update_class_list->setToolTip(QCoreApplication::translate("main_window", "<html><head/><body><p><span style=\" font-size:9pt;\">Debug Button</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        update_class_list->setText(QCoreApplication::translate("main_window", "Update", nullptr));
        class_label->setText(QCoreApplication::translate("main_window", "Your Schedule", nullptr));
#if QT_CONFIG(tooltip)
        class_creator_button->setToolTip(QCoreApplication::translate("main_window", "<html><head/><body><p><span style=\" font-size:9pt;\">Add Class</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        class_creator_button->setText(QString());
#if QT_CONFIG(tooltip)
        clear_schedule_button->setToolTip(QCoreApplication::translate("main_window", "<html><head/><body><p>Clear All</p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        clear_schedule_button->setText(QString());
        CSUSM_label->setText(QCoreApplication::translate("main_window", "Map of CSUSM", nullptr));
        menuDebug->setTitle(QCoreApplication::translate("main_window", "Debug", nullptr));
    } // retranslateUi

};

namespace Ui {
    class main_window: public Ui_main_window {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
