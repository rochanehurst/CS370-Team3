/********************************************************************************
** Form generated from reading UI file 'class_info_unit.ui'
**
** Created by: Qt User Interface Compiler version 6.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLASS_INFO_UNIT_H
#define UI_CLASS_INFO_UNIT_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QToolButton>

QT_BEGIN_NAMESPACE

class Ui_class_info_frame
{
public:
    QGridLayout *gridLayout;
    QLabel *location_label;
    QLabel *time_label;
    QLabel *days_label;
    QLabel *class_name_label;
    QToolButton *tool_button;

    void setupUi(QFrame *class_info_frame)
    {
        if (class_info_frame->objectName().isEmpty())
            class_info_frame->setObjectName("class_info_frame");
        class_info_frame->resize(200, 125);
        QSizePolicy sizePolicy(QSizePolicy::Policy::MinimumExpanding, QSizePolicy::Policy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(class_info_frame->sizePolicy().hasHeightForWidth());
        class_info_frame->setSizePolicy(sizePolicy);
        class_info_frame->setMinimumSize(QSize(0, 0));
        QPalette palette;
        QBrush brush(QColor(11, 40, 85, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Button, brush);
        QBrush brush1(QColor(215, 231, 255, 255));
        brush1.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Light, brush1);
        QBrush brush2(QColor(111, 111, 111, 255));
        brush2.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Dark, brush2);
        QBrush brush3(QColor(3, 10, 21, 255));
        brush3.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Mid, brush3);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Text, brush3);
        QBrush brush4(QColor(255, 0, 0, 255));
        brush4.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::BrightText, brush4);
        QBrush brush5(QColor(255, 255, 255, 255));
        brush5.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ButtonText, brush5);
        QBrush brush6(QColor(153, 155, 159, 255));
        brush6.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Base, brush6);
        QBrush brush7(QColor(172, 172, 172, 255));
        brush7.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush7);
        QBrush brush8(QColor(6, 21, 43, 255));
        brush8.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Shadow, brush8);
        QBrush brush9(QColor(16, 61, 127, 255));
        brush9.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Highlight, brush9);
        QBrush brush10(QColor(0, 0, 255, 255));
        brush10.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Link, brush10);
        QBrush brush11(QColor(255, 85, 0, 255));
        brush11.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::LinkVisited, brush11);
        QBrush brush12(QColor(85, 119, 165, 255));
        brush12.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::AlternateBase, brush12);
        QBrush brush13(QColor(170, 255, 0, 255));
        brush13.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ToolTipBase, brush13);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ToolTipText, brush13);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Accent, brush);
#endif
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Button, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Light, brush1);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Dark, brush2);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Mid, brush3);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Text, brush3);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::BrightText, brush4);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ButtonText, brush5);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Base, brush6);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush7);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Shadow, brush8);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Highlight, brush9);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Link, brush10);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::LinkVisited, brush11);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::AlternateBase, brush12);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ToolTipBase, brush13);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ToolTipText, brush13);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Accent, brush);
#endif
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::WindowText, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Button, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Light, brush1);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Dark, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Mid, brush3);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Text, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::BrightText, brush4);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ButtonText, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush7);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush7);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Shadow, brush8);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Link, brush10);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::LinkVisited, brush11);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::AlternateBase, brush12);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ToolTipBase, brush13);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ToolTipText, brush13);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Accent, brush);
#endif
        class_info_frame->setPalette(palette);
        class_info_frame->setStyleSheet(QString::fromUtf8("QFrame:hover {\n"
"    background-color: rgb(150, 150, 150); /* medium gray (hover) */\n"
"    color: black;\n"
"	border: 1px solid black;\n"
"	border-radius: 4px;\n"
"}\n"
"\n"
"QLabel:hover{\n"
"	color: black;\n"
"	border: none;\n"
"}\n"
""));
        class_info_frame->setFrameShape(QFrame::Shape::Panel);
        gridLayout = new QGridLayout(class_info_frame);
        gridLayout->setObjectName("gridLayout");
        location_label = new QLabel(class_info_frame);
        location_label->setObjectName("location_label");
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(location_label->sizePolicy().hasHeightForWidth());
        location_label->setSizePolicy(sizePolicy1);
        QFont font;
        font.setPointSize(8);
        location_label->setFont(font);

        gridLayout->addWidget(location_label, 1, 0, 1, 1);

        time_label = new QLabel(class_info_frame);
        time_label->setObjectName("time_label");
        sizePolicy1.setHeightForWidth(time_label->sizePolicy().hasHeightForWidth());
        time_label->setSizePolicy(sizePolicy1);
        time_label->setFont(font);

        gridLayout->addWidget(time_label, 3, 0, 1, 2);

        days_label = new QLabel(class_info_frame);
        days_label->setObjectName("days_label");
        sizePolicy1.setHeightForWidth(days_label->sizePolicy().hasHeightForWidth());
        days_label->setSizePolicy(sizePolicy1);
        days_label->setFont(font);

        gridLayout->addWidget(days_label, 2, 0, 1, 1);

        class_name_label = new QLabel(class_info_frame);
        class_name_label->setObjectName("class_name_label");
        QSizePolicy sizePolicy2(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(class_name_label->sizePolicy().hasHeightForWidth());
        class_name_label->setSizePolicy(sizePolicy2);
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Lucida Console")});
        font1.setPointSize(10);
        font1.setBold(true);
        class_name_label->setFont(font1);
        class_name_label->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        class_name_label->setWordWrap(false);

        gridLayout->addWidget(class_name_label, 0, 0, 1, 2, Qt::AlignmentFlag::AlignLeft|Qt::AlignmentFlag::AlignVCenter);

        tool_button = new QToolButton(class_info_frame);
        tool_button->setObjectName("tool_button");
        sizePolicy1.setHeightForWidth(tool_button->sizePolicy().hasHeightForWidth());
        tool_button->setSizePolicy(sizePolicy1);
        tool_button->setMinimumSize(QSize(25, 25));
        tool_button->setMaximumSize(QSize(25, 25));
        QPalette palette1;
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::WindowText, brush5);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Button, brush);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Text, brush5);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ButtonText, brush5);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Base, brush);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush);
        QBrush brush14(QColor(255, 255, 255, 128));
        brush14.setStyle(Qt::BrushStyle::SolidPattern);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::PlaceholderText, brush14);
#endif
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::WindowText, brush5);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Button, brush);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Text, brush5);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ButtonText, brush5);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Base, brush);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::PlaceholderText, brush14);
#endif
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::WindowText, brush5);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Button, brush);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Text, brush5);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ButtonText, brush5);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::PlaceholderText, brush14);
#endif
        tool_button->setPalette(palette1);
        tool_button->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        tool_button->setStyleSheet(QString::fromUtf8("QToolButton {\n"
"	background-color: rgb(11, 40, 85);\n"
"	color: white;\n"
"}\n"
"\n"
"QToolButton:hover {\n"
"	background-color: rgb(5, 20, 40);\n"
"	color: white;\n"
"}\n"
"\n"
"QToolButton::menu-indicator{\n"
"	image: none;\n"
"}"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("icons/Windows_Settings_app_icon.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        tool_button->setIcon(icon);
        tool_button->setIconSize(QSize(24, 24));
        tool_button->setPopupMode(QToolButton::ToolButtonPopupMode::InstantPopup);
        tool_button->setToolButtonStyle(Qt::ToolButtonStyle::ToolButtonIconOnly);
        tool_button->setArrowType(Qt::ArrowType::NoArrow);

        gridLayout->addWidget(tool_button, 0, 2, 1, 1, Qt::AlignmentFlag::AlignRight);


        retranslateUi(class_info_frame);

        QMetaObject::connectSlotsByName(class_info_frame);
    } // setupUi

    void retranslateUi(QFrame *class_info_frame)
    {
        class_info_frame->setWindowTitle(QCoreApplication::translate("class_info_frame", "Frame", nullptr));
        location_label->setText(QCoreApplication::translate("class_info_frame", "LOCATION", nullptr));
        time_label->setText(QCoreApplication::translate("class_info_frame", "TIME", nullptr));
        days_label->setText(QCoreApplication::translate("class_info_frame", "DAYS", nullptr));
        class_name_label->setText(QCoreApplication::translate("class_info_frame", "CLASS NAME", nullptr));
#if QT_CONFIG(tooltip)
        tool_button->setToolTip(QCoreApplication::translate("class_info_frame", "Options", nullptr));
#endif // QT_CONFIG(tooltip)
        tool_button->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class class_info_frame: public Ui_class_info_frame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLASS_INFO_UNIT_H
