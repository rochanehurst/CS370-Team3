/********************************************************************************
** Form generated from reading UI file 'class_result.ui'
**
** Created by: Qt User Interface Compiler version 6.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLASS_RESULT_H
#define UI_CLASS_RESULT_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_class_result
{
public:
    QGridLayout *gridLayout;
    QGridLayout *the_one_true_grid;
    QLabel *days;
    QPushButton *add_button;
    QLabel *subject;
    QLabel *buildings;
    QLabel *time;
    QLabel *class_name;
    QLabel *class_code;
    QLabel *instructors;

    void setupUi(QFrame *class_result)
    {
        if (class_result->objectName().isEmpty())
            class_result->setObjectName("class_result");
        class_result->resize(451, 100);
        QSizePolicy sizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(class_result->sizePolicy().hasHeightForWidth());
        class_result->setSizePolicy(sizePolicy);
        class_result->setMinimumSize(QSize(300, 100));
        class_result->setMaximumSize(QSize(16777215, 150));
        QPalette palette;
        QBrush brush(QColor(11, 40, 85, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Button, brush);
        QBrush brush1(QColor(215, 231, 255, 255));
        brush1.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Light, brush1);
        QBrush brush2(QColor(170, 255, 0, 255));
        brush2.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Dark, brush2);
        QBrush brush3(QColor(3, 10, 21, 255));
        brush3.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Mid, brush3);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Text, brush3);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::BrightText, brush2);
        QBrush brush4(QColor(255, 255, 255, 255));
        brush4.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ButtonText, brush4);
        QBrush brush5(QColor(153, 155, 159, 255));
        brush5.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Base, brush5);
        QBrush brush6(QColor(172, 172, 172, 255));
        brush6.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush6);
        QBrush brush7(QColor(6, 21, 43, 255));
        brush7.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Shadow, brush7);
        QBrush brush8(QColor(16, 61, 127, 255));
        brush8.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Highlight, brush8);
        QBrush brush9(QColor(0, 0, 255, 255));
        brush9.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Link, brush9);
        QBrush brush10(QColor(255, 85, 0, 255));
        brush10.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::LinkVisited, brush10);
        QBrush brush11(QColor(85, 119, 165, 255));
        brush11.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::AlternateBase, brush11);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ToolTipBase, brush2);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ToolTipText, brush2);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Accent, brush);
#endif
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Button, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Light, brush1);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Dark, brush2);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Mid, brush3);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Text, brush3);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::BrightText, brush2);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ButtonText, brush4);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Base, brush5);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush6);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Shadow, brush7);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Highlight, brush8);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Link, brush9);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::LinkVisited, brush10);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::AlternateBase, brush11);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ToolTipBase, brush2);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ToolTipText, brush2);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Accent, brush);
#endif
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::WindowText, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Button, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Light, brush1);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Dark, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Mid, brush3);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Text, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::BrightText, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ButtonText, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush6);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush6);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Shadow, brush7);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Link, brush9);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::LinkVisited, brush10);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::AlternateBase, brush11);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ToolTipBase, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ToolTipText, brush2);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Accent, brush);
#endif
        class_result->setPalette(palette);
        class_result->setFrameShape(QFrame::Shape::Panel);
        gridLayout = new QGridLayout(class_result);
        gridLayout->setSpacing(0);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(4, 4, 4, 4);
        the_one_true_grid = new QGridLayout();
        the_one_true_grid->setObjectName("the_one_true_grid");
        the_one_true_grid->setHorizontalSpacing(12);
        days = new QLabel(class_result);
        days->setObjectName("days");
        sizePolicy.setHeightForWidth(days->sizePolicy().hasHeightForWidth());
        days->setSizePolicy(sizePolicy);
        days->setMinimumSize(QSize(150, 0));
        days->setMaximumSize(QSize(16777215, 16777215));

        the_one_true_grid->addWidget(days, 2, 0, 1, 1, Qt::AlignmentFlag::AlignLeft|Qt::AlignmentFlag::AlignVCenter);

        add_button = new QPushButton(class_result);
        add_button->setObjectName("add_button");
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(add_button->sizePolicy().hasHeightForWidth());
        add_button->setSizePolicy(sizePolicy1);
        add_button->setMinimumSize(QSize(24, 24));
        add_button->setMaximumSize(QSize(24, 24));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/icons/add_button.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        add_button->setIcon(icon);

        the_one_true_grid->addWidget(add_button, 0, 2, 1, 1, Qt::AlignmentFlag::AlignRight);

        subject = new QLabel(class_result);
        subject->setObjectName("subject");
        sizePolicy.setHeightForWidth(subject->sizePolicy().hasHeightForWidth());
        subject->setSizePolicy(sizePolicy);
        subject->setMinimumSize(QSize(175, 0));
        subject->setMaximumSize(QSize(16777215, 16777215));

        the_one_true_grid->addWidget(subject, 0, 0, 1, 1, Qt::AlignmentFlag::AlignLeft|Qt::AlignmentFlag::AlignTop);

        buildings = new QLabel(class_result);
        buildings->setObjectName("buildings");
        sizePolicy.setHeightForWidth(buildings->sizePolicy().hasHeightForWidth());
        buildings->setSizePolicy(sizePolicy);
        buildings->setMinimumSize(QSize(150, 0));
        buildings->setMaximumSize(QSize(300, 16777215));
        buildings->setWordWrap(true);

        the_one_true_grid->addWidget(buildings, 1, 0, 1, 1, Qt::AlignmentFlag::AlignLeft|Qt::AlignmentFlag::AlignTop);

        time = new QLabel(class_result);
        time->setObjectName("time");
        sizePolicy.setHeightForWidth(time->sizePolicy().hasHeightForWidth());
        time->setSizePolicy(sizePolicy);
        time->setMinimumSize(QSize(0, 0));
        time->setMaximumSize(QSize(16777215, 16777215));

        the_one_true_grid->addWidget(time, 2, 1, 1, 1, Qt::AlignmentFlag::AlignLeft|Qt::AlignmentFlag::AlignVCenter);

        class_name = new QLabel(class_result);
        class_name->setObjectName("class_name");
        sizePolicy.setHeightForWidth(class_name->sizePolicy().hasHeightForWidth());
        class_name->setSizePolicy(sizePolicy);
        class_name->setMinimumSize(QSize(0, 0));
        class_name->setMaximumSize(QSize(16777215, 16777215));
        class_name->setWordWrap(false);

        the_one_true_grid->addWidget(class_name, 0, 1, 1, 1, Qt::AlignmentFlag::AlignLeft|Qt::AlignmentFlag::AlignTop);

        class_code = new QLabel(class_result);
        class_code->setObjectName("class_code");
        sizePolicy.setHeightForWidth(class_code->sizePolicy().hasHeightForWidth());
        class_code->setSizePolicy(sizePolicy);
        class_code->setMinimumSize(QSize(0, 0));
        class_code->setMaximumSize(QSize(16777215, 16777215));
        QFont font;
        font.setPointSize(7);
        class_code->setFont(font);

        the_one_true_grid->addWidget(class_code, 3, 0, 1, 1, Qt::AlignmentFlag::AlignLeft|Qt::AlignmentFlag::AlignTop);

        instructors = new QLabel(class_result);
        instructors->setObjectName("instructors");
        sizePolicy.setHeightForWidth(instructors->sizePolicy().hasHeightForWidth());
        instructors->setSizePolicy(sizePolicy);
        instructors->setMinimumSize(QSize(0, 0));
        instructors->setMaximumSize(QSize(16777215, 16777215));

        the_one_true_grid->addWidget(instructors, 1, 1, 1, 1, Qt::AlignmentFlag::AlignLeft|Qt::AlignmentFlag::AlignTop);

        the_one_true_grid->setColumnStretch(1, 1);

        gridLayout->addLayout(the_one_true_grid, 0, 0, 1, 1);


        retranslateUi(class_result);

        QMetaObject::connectSlotsByName(class_result);
    } // setupUi

    void retranslateUi(QFrame *class_result)
    {
        class_result->setWindowTitle(QCoreApplication::translate("class_result", "Frame", nullptr));
        days->setText(QCoreApplication::translate("class_result", "DAY(S)", nullptr));
        add_button->setText(QString());
        subject->setText(QCoreApplication::translate("class_result", "SUBJECT", nullptr));
        buildings->setText(QCoreApplication::translate("class_result", "BUILDING(S)", nullptr));
        time->setText(QCoreApplication::translate("class_result", "TIME", nullptr));
        class_name->setText(QCoreApplication::translate("class_result", "CLASS NAME", nullptr));
        class_code->setText(QCoreApplication::translate("class_result", "Class Code", nullptr));
        instructors->setText(QCoreApplication::translate("class_result", "INSTRUCTOR(S)", nullptr));
    } // retranslateUi

};

namespace Ui {
    class class_result: public Ui_class_result {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLASS_RESULT_H
