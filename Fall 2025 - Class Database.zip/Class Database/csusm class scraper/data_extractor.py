from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.by import By
import pandas as pd
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

#options = webdriver.ChromeOptions()
#options.add_argument("--headless")
#driver = webdriver.Chrome(options=options)
driver = webdriver.Chrome()
driver.get("https://cmsweb.csusm.edu/psp/CSMPRDP/EMPLOYEE/HRMS/c/COMMUNITY_ACCESS.CLASS_SEARCH.GBL?")

subjects = pd.read_csv(r"C:\Users\coleo\Desktop\Class Database\subjects.csv", header=None, names=["Subject"])

rows = []
numOfClass = 0

for subject in subjects["Subject"]:
    print(f"Looking through {subject}")

    wait = WebDriverWait(driver, 60)
    short_wait = WebDriverWait(driver, 5)

    # Always start at default content
    driver.switch_to.default_content()
    iframe = wait.until(EC.presence_of_element_located((By.ID, "ptifrmtgtframe")))
    driver.switch_to.frame(iframe)

    clear_button = wait.until(
        EC.presence_of_element_located((By.ID, "CLASS_SRCH_WRK2_SSR_PB_CLEAR"))
    )
    clear_button.click()
    time.sleep(2)

    # Re-locate iframe after clearing
    driver.switch_to.default_content()
    iframe = wait.until(EC.presence_of_element_located((By.ID, "ptifrmtgtframe")))
    driver.switch_to.frame(iframe)

    # Now find dropdown safely
    subject_dropdown = wait.until(
        EC.presence_of_element_located((By.ID, "SSR_CLSRCH_WRK_SUBJECT_SRCH$0"))
    )
    select = Select(subject_dropdown)
    select.select_by_visible_text(subject)


    search_button = wait.until(
        EC.presence_of_element_located((By.ID, "CLASS_SRCH_WRK2_SSR_PB_CLASS_SRCH"))
    )
    search_button.click()

    try:
        error_msg = short_wait.until(
            EC.presence_of_element_located((By.ID, "DERIVED_CLSMSG_ERROR_TEXT"))
        )
        print(f"No classes found for {subject}")
        continue  # skip parsing
    except:
        pass  # No error found

    try:
        ok_command = short_wait.until(
            EC.presence_of_element_located((By.ID, "#ICSave"))
        )
        ok_command.click()
        time.sleep(5)
    except:
        pass  # No error found

    wait.until(EC.presence_of_element_located((By.ID, "win0divSSR_CLSRCH_MTG1$0")))

    from bs4 import BeautifulSoup
    soup = BeautifulSoup(driver.page_source, "html.parser")


    print("Looking through classes")
    for tr in soup.find_all("tr", id=lambda x: x and x.startswith("trSSR_CLSRCH_MTG1")):
        class_name_tag = soup.find("img", class_="PTCOLLAPSE")
        if class_name_tag:
            class_name = class_name_tag["alt"].replace(" Collapsible section", "").strip()
        else:
            class_name = subject

        class_number = tr.find("span", id=lambda x: x and x.startswith("MTG_CLASS_NBR")).text.strip()
        instructor = tr.find("span", id=lambda x: x and x.startswith("MTG_INSTR")).text.strip()
        location = tr.find("span", id=lambda x: x and x.startswith("MTG_ROOM")).text.strip()
        times = tr.find("span", id=lambda x: x and x.startswith("MTG_DAYTIME")).text.strip()

        rows.append({
            "Major": subject,
            "Class Name": class_name,
            "Class Code": class_number,
            "Instructor": instructor,
            "Location": location,
            "Days & Times": times
        })

        numOfClass += 1
        print(f"Found {numOfClass} class(es)")

    # click New Search to reset form
    new_search = wait.until(
        EC.presence_of_element_located((By.ID, "CLASS_SRCH_WRK2_SSR_PB_NEW_SEARCH"))
    )
    new_search.click()

    # ✅ Always return to default content
    driver.switch_to.default_content()
    time.sleep(1)

df = pd.DataFrame(rows)
df.to_csv(r"C:\Users\coleo\Desktop\Class Database\csusm_classes.csv", index=False)
print("✅ Exported results!")
driver.quit()