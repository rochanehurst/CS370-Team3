/********************************************************************************
** Form generated from reading UI file 'search_window.ui'
**
** Created by: Qt User Interface Compiler version 6.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEARCH_WINDOW_H
#define UI_SEARCH_WINDOW_H

#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QTimeEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_search_window
{
public:
    QGridLayout *gridLayout_3;
    QProgressBar *progressBar;
    QFrame *days;
    QVBoxLayout *verticalLayout;
    QCheckBox *monday;
    QCheckBox *tuesday;
    QCheckBox *wednesday;
    QCheckBox *thursday;
    QCheckBox *friday;
    QCheckBox *saturday;
    QGridLayout *search_box;
    QLabel *lbl_subject;
    QLabel *lbl_endbefore;
    QLabel *lbl_classname;
    QTimeEdit *time_endbefore;
    QLabel *lbl_building;
    QLabel *lbl_startafter;
    QTimeEdit *time_startafter;
    QLineEdit *input_class;
    QComboBox *building_combo_box;
    QComboBox *subject_combo_box;
    QPushButton *reset_time;
    QScrollArea *results;
    QWidget *scrollAreaWidgetContents;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *scroll_list;
    QLabel *no_classes;

    void setupUi(QDialog *search_window)
    {
        if (search_window->objectName().isEmpty())
            search_window->setObjectName("search_window");
        search_window->setEnabled(true);
        search_window->resize(625, 400);
        QSizePolicy sizePolicy(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(search_window->sizePolicy().hasHeightForWidth());
        search_window->setSizePolicy(sizePolicy);
        search_window->setMinimumSize(QSize(625, 400));
        search_window->setMaximumSize(QSize(900, 1600));
        QPalette palette;
        QBrush brush(QColor(11, 40, 85, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Button, brush);
        QBrush brush1(QColor(215, 231, 255, 255));
        brush1.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Light, brush1);
        QBrush brush2(QColor(111, 111, 111, 255));
        brush2.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Dark, brush2);
        QBrush brush3(QColor(3, 10, 21, 255));
        brush3.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Mid, brush3);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Text, brush3);
        QBrush brush4(QColor(255, 0, 0, 255));
        brush4.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::BrightText, brush4);
        QBrush brush5(QColor(255, 255, 255, 255));
        brush5.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ButtonText, brush5);
        QBrush brush6(QColor(153, 155, 159, 255));
        brush6.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Base, brush6);
        QBrush brush7(QColor(172, 172, 172, 255));
        brush7.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush7);
        QBrush brush8(QColor(6, 21, 43, 255));
        brush8.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Shadow, brush8);
        QBrush brush9(QColor(16, 61, 127, 255));
        brush9.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Highlight, brush9);
        QBrush brush10(QColor(0, 0, 255, 255));
        brush10.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Link, brush10);
        QBrush brush11(QColor(255, 85, 0, 255));
        brush11.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::LinkVisited, brush11);
        QBrush brush12(QColor(85, 119, 165, 255));
        brush12.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::AlternateBase, brush12);
        QBrush brush13(QColor(170, 255, 0, 255));
        brush13.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ToolTipBase, brush13);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::ToolTipText, brush13);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Accent, brush);
#endif
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Button, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Light, brush1);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Dark, brush2);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Mid, brush3);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Text, brush3);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::BrightText, brush4);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ButtonText, brush5);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Base, brush6);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush7);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Shadow, brush8);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Highlight, brush9);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Link, brush10);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::LinkVisited, brush11);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::AlternateBase, brush12);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ToolTipBase, brush13);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::ToolTipText, brush13);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Accent, brush);
#endif
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::WindowText, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Button, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Light, brush1);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Dark, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Mid, brush3);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Text, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::BrightText, brush4);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ButtonText, brush2);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush7);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush7);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Shadow, brush8);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Link, brush10);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::LinkVisited, brush11);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::AlternateBase, brush12);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ToolTipBase, brush13);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::ToolTipText, brush13);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Accent, brush);
#endif
        search_window->setPalette(palette);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/icons/Create Class Icon Placeholder.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        search_window->setWindowIcon(icon);
        search_window->setSizeGripEnabled(true);
        gridLayout_3 = new QGridLayout(search_window);
        gridLayout_3->setObjectName("gridLayout_3");
        progressBar = new QProgressBar(search_window);
        progressBar->setObjectName("progressBar");
        progressBar->setMinimumSize(QSize(200, 0));
        progressBar->setValue(24);

        gridLayout_3->addWidget(progressBar, 2, 0, 1, 2, Qt::AlignmentFlag::AlignHCenter);

        days = new QFrame(search_window);
        days->setObjectName("days");
        days->setEnabled(true);
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(days->sizePolicy().hasHeightForWidth());
        days->setSizePolicy(sizePolicy1);
        days->setMinimumSize(QSize(0, 150));
        days->setMaximumSize(QSize(125, 150));
        days->setFrameShape(QFrame::Shape::StyledPanel);
        days->setFrameShadow(QFrame::Shadow::Raised);
        verticalLayout = new QVBoxLayout(days);
        verticalLayout->setObjectName("verticalLayout");
        monday = new QCheckBox(days);
        monday->setObjectName("monday");

        verticalLayout->addWidget(monday);

        tuesday = new QCheckBox(days);
        tuesday->setObjectName("tuesday");

        verticalLayout->addWidget(tuesday);

        wednesday = new QCheckBox(days);
        wednesday->setObjectName("wednesday");

        verticalLayout->addWidget(wednesday);

        thursday = new QCheckBox(days);
        thursday->setObjectName("thursday");

        verticalLayout->addWidget(thursday);

        friday = new QCheckBox(days);
        friday->setObjectName("friday");

        verticalLayout->addWidget(friday);

        saturday = new QCheckBox(days);
        saturday->setObjectName("saturday");

        verticalLayout->addWidget(saturday);


        gridLayout_3->addWidget(days, 1, 1, 1, 1);

        search_box = new QGridLayout();
        search_box->setObjectName("search_box");
        search_box->setVerticalSpacing(6);
        search_box->setContentsMargins(6, 6, 6, 6);
        lbl_subject = new QLabel(search_window);
        lbl_subject->setObjectName("lbl_subject");
        sizePolicy1.setHeightForWidth(lbl_subject->sizePolicy().hasHeightForWidth());
        lbl_subject->setSizePolicy(sizePolicy1);
        lbl_subject->setMinimumSize(QSize(100, 0));

        search_box->addWidget(lbl_subject, 0, 0, 1, 1);

        lbl_endbefore = new QLabel(search_window);
        lbl_endbefore->setObjectName("lbl_endbefore");
        sizePolicy1.setHeightForWidth(lbl_endbefore->sizePolicy().hasHeightForWidth());
        lbl_endbefore->setSizePolicy(sizePolicy1);
        lbl_endbefore->setMinimumSize(QSize(100, 0));

        search_box->addWidget(lbl_endbefore, 3, 2, 1, 1, Qt::AlignmentFlag::AlignLeft);

        lbl_classname = new QLabel(search_window);
        lbl_classname->setObjectName("lbl_classname");
        sizePolicy1.setHeightForWidth(lbl_classname->sizePolicy().hasHeightForWidth());
        lbl_classname->setSizePolicy(sizePolicy1);

        search_box->addWidget(lbl_classname, 2, 0, 1, 1, Qt::AlignmentFlag::AlignLeft);

        time_endbefore = new QTimeEdit(search_window);
        time_endbefore->setObjectName("time_endbefore");
        QSizePolicy sizePolicy2(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(time_endbefore->sizePolicy().hasHeightForWidth());
        time_endbefore->setSizePolicy(sizePolicy2);
        time_endbefore->setMaximumDateTime(QDateTime(QDate(2000, 1, 1), QTime(22, 0, 0)));
        time_endbefore->setMaximumDate(QDate(2000, 1, 1));
        time_endbefore->setMaximumTime(QTime(22, 0, 0));
        time_endbefore->setMinimumTime(QTime(8, 30, 0));
        time_endbefore->setTime(QTime(22, 0, 0));

        search_box->addWidget(time_endbefore, 3, 3, 1, 1);

        lbl_building = new QLabel(search_window);
        lbl_building->setObjectName("lbl_building");
        sizePolicy1.setHeightForWidth(lbl_building->sizePolicy().hasHeightForWidth());
        lbl_building->setSizePolicy(sizePolicy1);

        search_box->addWidget(lbl_building, 1, 0, 1, 1, Qt::AlignmentFlag::AlignLeft);

        lbl_startafter = new QLabel(search_window);
        lbl_startafter->setObjectName("lbl_startafter");
        sizePolicy1.setHeightForWidth(lbl_startafter->sizePolicy().hasHeightForWidth());
        lbl_startafter->setSizePolicy(sizePolicy1);
        lbl_startafter->setMinimumSize(QSize(100, 0));

        search_box->addWidget(lbl_startafter, 3, 0, 1, 1, Qt::AlignmentFlag::AlignVCenter);

        time_startafter = new QTimeEdit(search_window);
        time_startafter->setObjectName("time_startafter");
        sizePolicy2.setHeightForWidth(time_startafter->sizePolicy().hasHeightForWidth());
        time_startafter->setSizePolicy(sizePolicy2);
        time_startafter->setMaximumDateTime(QDateTime(QDate(2000, 1, 1), QTime(20, 0, 0)));
        time_startafter->setMinimumDateTime(QDateTime(QDate(2000, 1, 1), QTime(6, 0, 0)));
        time_startafter->setMaximumDate(QDate(2000, 1, 1));
        time_startafter->setMaximumTime(QTime(20, 0, 0));
        time_startafter->setMinimumTime(QTime(6, 0, 0));
        time_startafter->setTime(QTime(6, 0, 0));

        search_box->addWidget(time_startafter, 3, 1, 1, 1);

        input_class = new QLineEdit(search_window);
        input_class->setObjectName("input_class");
        QSizePolicy sizePolicy3(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(input_class->sizePolicy().hasHeightForWidth());
        input_class->setSizePolicy(sizePolicy3);
        input_class->setMinimumSize(QSize(150, 0));
        input_class->setMaximumSize(QSize(16777215, 16777215));

        search_box->addWidget(input_class, 2, 1, 1, 4);

        building_combo_box = new QComboBox(search_window);
        building_combo_box->addItem(QString());
        building_combo_box->addItem(QString());
        building_combo_box->addItem(QString());
        building_combo_box->addItem(QString());
        building_combo_box->addItem(QString());
        building_combo_box->addItem(QString());
        building_combo_box->addItem(QString());
        building_combo_box->addItem(QString());
        building_combo_box->addItem(QString());
        building_combo_box->addItem(QString());
        building_combo_box->addItem(QString());
        building_combo_box->addItem(QString());
        building_combo_box->setObjectName("building_combo_box");
        building_combo_box->setMaximumSize(QSize(16777215, 16777215));
        building_combo_box->setMaxVisibleItems(15);

        search_box->addWidget(building_combo_box, 1, 1, 1, 4);

        subject_combo_box = new QComboBox(search_window);
        subject_combo_box->setObjectName("subject_combo_box");
        subject_combo_box->setMaximumSize(QSize(16777215, 16777215));

        search_box->addWidget(subject_combo_box, 0, 1, 1, 4);

        reset_time = new QPushButton(search_window);
        reset_time->setObjectName("reset_time");
        sizePolicy1.setHeightForWidth(reset_time->sizePolicy().hasHeightForWidth());
        reset_time->setSizePolicy(sizePolicy1);
        reset_time->setMaximumSize(QSize(68, 16777215));

        search_box->addWidget(reset_time, 3, 4, 1, 1);


        gridLayout_3->addLayout(search_box, 1, 0, 1, 1);

        results = new QScrollArea(search_window);
        results->setObjectName("results");
        QSizePolicy sizePolicy4(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Preferred);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(results->sizePolicy().hasHeightForWidth());
        results->setSizePolicy(sizePolicy4);
        results->setMaximumSize(QSize(16777215, 16777215));
        results->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName("scrollAreaWidgetContents");
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 605, 93));
        verticalLayout_2 = new QVBoxLayout(scrollAreaWidgetContents);
        verticalLayout_2->setObjectName("verticalLayout_2");
        scroll_list = new QVBoxLayout();
        scroll_list->setSpacing(8);
        scroll_list->setObjectName("scroll_list");

        verticalLayout_2->addLayout(scroll_list);

        results->setWidget(scrollAreaWidgetContents);

        gridLayout_3->addWidget(results, 4, 0, 1, 2);

        no_classes = new QLabel(search_window);
        no_classes->setObjectName("no_classes");
        QFont font;
        font.setFamilies({QString::fromUtf8("Courier New")});
        font.setPointSize(20);
        font.setBold(true);
        no_classes->setFont(font);
        no_classes->setAlignment(Qt::AlignmentFlag::AlignCenter);

        gridLayout_3->addWidget(no_classes, 3, 0, 1, 2);


        retranslateUi(search_window);

        QMetaObject::connectSlotsByName(search_window);
    } // setupUi

    void retranslateUi(QDialog *search_window)
    {
        search_window->setWindowTitle(QCoreApplication::translate("search_window", "Search Class", nullptr));
#if QT_CONFIG(tooltip)
        search_window->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        days->setToolTip(QCoreApplication::translate("search_window", "<html><head/><body><p>Select days in which class occurs</p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        monday->setText(QCoreApplication::translate("search_window", "Monday", nullptr));
        tuesday->setText(QCoreApplication::translate("search_window", "Tuesday", nullptr));
        wednesday->setText(QCoreApplication::translate("search_window", "Wednesday", nullptr));
        thursday->setText(QCoreApplication::translate("search_window", "Thursday", nullptr));
        friday->setText(QCoreApplication::translate("search_window", "Friday", nullptr));
        saturday->setText(QCoreApplication::translate("search_window", "Saturday", nullptr));
        lbl_subject->setText(QCoreApplication::translate("search_window", "Subject:", nullptr));
        lbl_endbefore->setText(QCoreApplication::translate("search_window", "Ends Before:", nullptr));
        lbl_classname->setText(QCoreApplication::translate("search_window", "Class Name:", nullptr));
        time_endbefore->setDisplayFormat(QCoreApplication::translate("search_window", "h:mmA", nullptr));
        lbl_building->setText(QCoreApplication::translate("search_window", "Building:", nullptr));
        lbl_startafter->setText(QCoreApplication::translate("search_window", "Starts After:", nullptr));
        time_startafter->setDisplayFormat(QCoreApplication::translate("search_window", "h:mmA", nullptr));
        building_combo_box->setItemText(0, QCoreApplication::translate("search_window", "NO BUILDING SELECTED", nullptr));
        building_combo_box->setItemText(1, QCoreApplication::translate("search_window", "Academic Hall", nullptr));
        building_combo_box->setItemText(2, QCoreApplication::translate("search_window", "Arts Building", nullptr));
        building_combo_box->setItemText(3, QCoreApplication::translate("search_window", "Extended Learning Building", nullptr));
        building_combo_box->setItemText(4, QCoreApplication::translate("search_window", "Kellogg Library", nullptr));
        building_combo_box->setItemText(5, QCoreApplication::translate("search_window", "Markstein Hall", nullptr));
        building_combo_box->setItemText(6, QCoreApplication::translate("search_window", "Science Hall I", nullptr));
        building_combo_box->setItemText(7, QCoreApplication::translate("search_window", "Science Hall II", nullptr));
        building_combo_box->setItemText(8, QCoreApplication::translate("search_window", "Soc & Behavioral Sci Bldg", nullptr));
        building_combo_box->setItemText(9, QCoreApplication::translate("search_window", "University Hall", nullptr));
        building_combo_box->setItemText(10, QCoreApplication::translate("search_window", "Viasat Engineering Pav", nullptr));
        building_combo_box->setItemText(11, QCoreApplication::translate("search_window", "ONLINE", nullptr));

        building_combo_box->setCurrentText(QCoreApplication::translate("search_window", "NO BUILDING SELECTED", nullptr));
        reset_time->setText(QCoreApplication::translate("search_window", "Reset", nullptr));
        no_classes->setText(QCoreApplication::translate("search_window", "No Classes Found", nullptr));
    } // retranslateUi

};

namespace Ui {
    class search_window: public Ui_search_window {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEARCH_WINDOW_H
