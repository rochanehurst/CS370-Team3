/****************************************************************************
** Meta object code from reading C++ file 'apimap.h'
**
** Created by: The Qt Meta Object Compiler version 69 (Qt 6.9.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../apimap.h"
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'apimap.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 69
#error "This file was generated using the moc from 6.9.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN6ApiMapE_t {};
} // unnamed namespace

template <> constexpr inline auto ApiMap::qt_create_metaobjectdata<qt_meta_tag_ZN6ApiMapE_t>()
{
    namespace QMC = QtMocConstants;
    QtMocHelpers::StringRefStorage qt_stringData {
        "ApiMap",
        "coordinatesReceived",
        "",
        "QGeoCoordinate",
        "coordinate",
        "routeReceived",
        "QList<QGeoCoordinate>",
        "route",
        "apiError",
        "errorString",
        "routeReceivedQml",
        "QVariantList",
        "markerCoordinate",
        "latitutde",
        "longitude",
        "removeMarker",
        "latitude",
        "longitutde",
        "removeAll",
        "addInfo",
        "info",
        "removeInfo",
        "mapRoute",
        "points",
        "routeReady",
        "routeCooords",
        "noRoute",
        "handleGeocodingReply",
        "QNetworkReply*",
        "reply",
        "handleRoutingReply"
    };

    QtMocHelpers::UintData qt_methods {
        // Signal 'coordinatesReceived'
        QtMocHelpers::SignalData<void(const QGeoCoordinate &)>(1, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 3, 4 },
        }}),
        // Signal 'routeReceived'
        QtMocHelpers::SignalData<void(const QList<QGeoCoordinate> &)>(5, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 6, 7 },
        }}),
        // Signal 'apiError'
        QtMocHelpers::SignalData<void(const QString &)>(8, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 9 },
        }}),
        // Signal 'routeReceivedQml'
        QtMocHelpers::SignalData<void(const QVariantList &)>(10, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 11, 7 },
        }}),
        // Signal 'markerCoordinate'
        QtMocHelpers::SignalData<void(double, double)>(12, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Double, 13 }, { QMetaType::Double, 14 },
        }}),
        // Signal 'removeMarker'
        QtMocHelpers::SignalData<void(double, double)>(15, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Double, 16 }, { QMetaType::Double, 17 },
        }}),
        // Signal 'removeAll'
        QtMocHelpers::SignalData<void()>(18, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'addInfo'
        QtMocHelpers::SignalData<void(double, double, const QString &)>(19, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Double, 16 }, { QMetaType::Double, 17 }, { QMetaType::QString, 20 },
        }}),
        // Signal 'removeInfo'
        QtMocHelpers::SignalData<void(double, double, const QString &)>(21, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Double, 16 }, { QMetaType::Double, 17 }, { QMetaType::QString, 20 },
        }}),
        // Signal 'mapRoute'
        QtMocHelpers::SignalData<void(const QList<QGeoCoordinate> &)>(22, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 6, 23 },
        }}),
        // Signal 'routeReady'
        QtMocHelpers::SignalData<void(const QVariantList &)>(24, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 11, 25 },
        }}),
        // Signal 'noRoute'
        QtMocHelpers::SignalData<void()>(26, 2, QMC::AccessPublic, QMetaType::Void),
        // Slot 'handleGeocodingReply'
        QtMocHelpers::SlotData<void(QNetworkReply *)>(27, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { 0x80000000 | 28, 29 },
        }}),
        // Slot 'handleRoutingReply'
        QtMocHelpers::SlotData<void(QNetworkReply *)>(30, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { 0x80000000 | 28, 29 },
        }}),
    };
    QtMocHelpers::UintData qt_properties {
    };
    QtMocHelpers::UintData qt_enums {
    };
    return QtMocHelpers::metaObjectData<ApiMap, qt_meta_tag_ZN6ApiMapE_t>(QMC::MetaObjectFlag{}, qt_stringData,
            qt_methods, qt_properties, qt_enums);
}
Q_CONSTINIT const QMetaObject ApiMap::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN6ApiMapE_t>.stringdata,
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN6ApiMapE_t>.data,
    qt_static_metacall,
    nullptr,
    qt_staticMetaObjectRelocatingContent<qt_meta_tag_ZN6ApiMapE_t>.metaTypes,
    nullptr
} };

void ApiMap::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<ApiMap *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->coordinatesReceived((*reinterpret_cast< std::add_pointer_t<QGeoCoordinate>>(_a[1]))); break;
        case 1: _t->routeReceived((*reinterpret_cast< std::add_pointer_t<QList<QGeoCoordinate>>>(_a[1]))); break;
        case 2: _t->apiError((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 3: _t->routeReceivedQml((*reinterpret_cast< std::add_pointer_t<QVariantList>>(_a[1]))); break;
        case 4: _t->markerCoordinate((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2]))); break;
        case 5: _t->removeMarker((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2]))); break;
        case 6: _t->removeAll(); break;
        case 7: _t->addInfo((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3]))); break;
        case 8: _t->removeInfo((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3]))); break;
        case 9: _t->mapRoute((*reinterpret_cast< std::add_pointer_t<QList<QGeoCoordinate>>>(_a[1]))); break;
        case 10: _t->routeReady((*reinterpret_cast< std::add_pointer_t<QVariantList>>(_a[1]))); break;
        case 11: _t->noRoute(); break;
        case 12: _t->handleGeocodingReply((*reinterpret_cast< std::add_pointer_t<QNetworkReply*>>(_a[1]))); break;
        case 13: _t->handleRoutingReply((*reinterpret_cast< std::add_pointer_t<QNetworkReply*>>(_a[1]))); break;
        default: ;
        }
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QGeoCoordinate >(); break;
            }
            break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QList<QGeoCoordinate> >(); break;
            }
            break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QList<QGeoCoordinate> >(); break;
            }
            break;
        case 12:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QNetworkReply* >(); break;
            }
            break;
        case 13:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QNetworkReply* >(); break;
            }
            break;
        }
    }
    if (_c == QMetaObject::IndexOfMethod) {
        if (QtMocHelpers::indexOfMethod<void (ApiMap::*)(const QGeoCoordinate & )>(_a, &ApiMap::coordinatesReceived, 0))
            return;
        if (QtMocHelpers::indexOfMethod<void (ApiMap::*)(const QList<QGeoCoordinate> & )>(_a, &ApiMap::routeReceived, 1))
            return;
        if (QtMocHelpers::indexOfMethod<void (ApiMap::*)(const QString & )>(_a, &ApiMap::apiError, 2))
            return;
        if (QtMocHelpers::indexOfMethod<void (ApiMap::*)(const QVariantList & )>(_a, &ApiMap::routeReceivedQml, 3))
            return;
        if (QtMocHelpers::indexOfMethod<void (ApiMap::*)(double , double )>(_a, &ApiMap::markerCoordinate, 4))
            return;
        if (QtMocHelpers::indexOfMethod<void (ApiMap::*)(double , double )>(_a, &ApiMap::removeMarker, 5))
            return;
        if (QtMocHelpers::indexOfMethod<void (ApiMap::*)()>(_a, &ApiMap::removeAll, 6))
            return;
        if (QtMocHelpers::indexOfMethod<void (ApiMap::*)(double , double , const QString & )>(_a, &ApiMap::addInfo, 7))
            return;
        if (QtMocHelpers::indexOfMethod<void (ApiMap::*)(double , double , const QString & )>(_a, &ApiMap::removeInfo, 8))
            return;
        if (QtMocHelpers::indexOfMethod<void (ApiMap::*)(const QList<QGeoCoordinate> & )>(_a, &ApiMap::mapRoute, 9))
            return;
        if (QtMocHelpers::indexOfMethod<void (ApiMap::*)(const QVariantList & )>(_a, &ApiMap::routeReady, 10))
            return;
        if (QtMocHelpers::indexOfMethod<void (ApiMap::*)()>(_a, &ApiMap::noRoute, 11))
            return;
    }
}

const QMetaObject *ApiMap::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ApiMap::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_staticMetaObjectStaticContent<qt_meta_tag_ZN6ApiMapE_t>.strings))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int ApiMap::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    }
    return _id;
}

// SIGNAL 0
void ApiMap::coordinatesReceived(const QGeoCoordinate & _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 0, nullptr, _t1);
}

// SIGNAL 1
void ApiMap::routeReceived(const QList<QGeoCoordinate> & _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 1, nullptr, _t1);
}

// SIGNAL 2
void ApiMap::apiError(const QString & _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 2, nullptr, _t1);
}

// SIGNAL 3
void ApiMap::routeReceivedQml(const QVariantList & _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 3, nullptr, _t1);
}

// SIGNAL 4
void ApiMap::markerCoordinate(double _t1, double _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 4, nullptr, _t1, _t2);
}

// SIGNAL 5
void ApiMap::removeMarker(double _t1, double _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 5, nullptr, _t1, _t2);
}

// SIGNAL 6
void ApiMap::removeAll()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void ApiMap::addInfo(double _t1, double _t2, const QString & _t3)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 7, nullptr, _t1, _t2, _t3);
}

// SIGNAL 8
void ApiMap::removeInfo(double _t1, double _t2, const QString & _t3)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 8, nullptr, _t1, _t2, _t3);
}

// SIGNAL 9
void ApiMap::mapRoute(const QList<QGeoCoordinate> & _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 9, nullptr, _t1);
}

// SIGNAL 10
void ApiMap::routeReady(const QVariantList & _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 10, nullptr, _t1);
}

// SIGNAL 11
void ApiMap::noRoute()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}
QT_WARNING_POP
