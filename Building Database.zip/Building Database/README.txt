Created 7/13/2025
Updated 7/14/2025

Update 1: Added Kellogg Library to data base

Data is ordered:
Building Name, Abbreviation of Name, # of Floors, Distance to other buildings (feet), (minutes)

Delimiter is ","

Distances were measure by Cole Leahy with the help of CalcMaps:
https://www.calcmaps.com/map-distance/

CalcMaps was found and suggested by Cassidy Klein

***All distance are rough estimations***
***Distance in minutes rounded to 2 decimal places***